function Küldés(){
    let Mnev = document.getElementById('Mnev').value;
    document.getElementById('Nev').value = Mnev;
    let Mcime = document.getElementById('Mcime').value;
    document.getElementById('Cim').value = Mcime;
    let Tszama = document.getElementById('Mtelszáma').value;
    document.getElementById('Tszama').value = Tszama;
}

function Rakatt(){
    document.getElementById('Mnev').style.backgroundColor = "lightblue";
}

function Rakatt2(){
    document.getElementById('Mcime').style.backgroundColor = "lightblue";
}

function Rakatt3(){
    document.getElementById('Mtelszáma').style.backgroundColor = "lightblue";
}

function Kikatt(){
    document.getElementById('Mnev').style.backgroundColor = "white"
}
function Kikatt2(){
    document.getElementById('Mcime').style.backgroundColor = "white";
}
function Kikatt3(){
    document.getElementById('Mtelszáma').style.backgroundColor = "white";
}